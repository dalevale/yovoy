<!DOCTYPE html>
<html>
    <body>	
    <div id="pie">   
		<ul>
			<li><a href='about.php'>SOBRE NOSOTROS</a></li>
			<li><a href='privacy.php'>PRIVACIDAD</a></li>
			<li><a href='contact.php'>CONTACTO</a></li>
			<li><a href='faq.php'>PREGUNTAS</a></li>
			<li>Yovoy &copy; 2020</li>
		</ul>
    </div>
	
	<script src="includes/js/eventItemButtons.js" type="text/javascript" ></script>
	<script src="includes/js/profileViewButtons.js" type="text/javascript" ></script>
    </body>
</html>